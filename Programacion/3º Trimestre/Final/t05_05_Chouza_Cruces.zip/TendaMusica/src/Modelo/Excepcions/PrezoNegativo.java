package Modelo.Excepcions;

public class PrezoNegativo extends Exception {
    
    public PrezoNegativo(String mensaxe){
        super(mensaxe);
    }
}
