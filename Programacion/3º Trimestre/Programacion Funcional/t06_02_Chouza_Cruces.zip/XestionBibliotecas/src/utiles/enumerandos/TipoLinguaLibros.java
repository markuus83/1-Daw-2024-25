package utiles.enumerandos;

public enum TipoLinguaLibros {
    GALEGO,
    CASTELAN,
    INGLES;
}
