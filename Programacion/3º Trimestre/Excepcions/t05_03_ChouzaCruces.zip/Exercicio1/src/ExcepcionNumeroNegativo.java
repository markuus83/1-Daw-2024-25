public class ExcepcionNumeroNegativo extends Exception {
    
    /**
     * 
     * @param message
     */
    public ExcepcionNumeroNegativo(String message) {
        super(message);
    }
}