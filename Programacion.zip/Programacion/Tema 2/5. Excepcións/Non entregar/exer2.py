#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" 
Escribe un script que pida ao usuario un número enteiro positivo. Se o usuario introduce un valor incorrecto (e dicir, un valor que non sexa un número ou non é positivo), o programa debe volver a pedir o número ata que o usuario introduza un valor válido. Para finalizar o script mostra o número de veces que se intentou introducir un número ata que este fose un enteiro positivo.
"""

__author__ = "Marcos Chouza Cruces"