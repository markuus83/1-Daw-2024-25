package Utiles.Enumerandos;

public enum TipoInstrumentoMusical {
    FRAUTA,
    SAXOFON,
    TROMBON;
}
