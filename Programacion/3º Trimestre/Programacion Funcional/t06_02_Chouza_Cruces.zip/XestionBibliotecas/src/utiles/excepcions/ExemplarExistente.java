package utiles.excepcions;

public class ExemplarExistente extends Exception {
    public ExemplarExistente(String mensaxe){
        super(mensaxe);
    }
}
