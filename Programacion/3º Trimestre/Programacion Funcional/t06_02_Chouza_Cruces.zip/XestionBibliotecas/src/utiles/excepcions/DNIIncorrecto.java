package utiles.excepcions;

public class DNIIncorrecto extends Exception{
    
    public DNIIncorrecto(String mensaxe){
        super(mensaxe);
    }

}
