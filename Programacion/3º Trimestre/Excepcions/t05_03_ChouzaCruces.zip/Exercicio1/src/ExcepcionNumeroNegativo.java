public class ExcepcionNumeroNegativo extends Exception{

    public ExcepcionNumeroNegativo(String mensaxe){
        super(mensaxe);
    }
    
}
