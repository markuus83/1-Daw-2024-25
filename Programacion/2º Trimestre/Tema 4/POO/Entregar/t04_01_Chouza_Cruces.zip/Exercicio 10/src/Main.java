public class Main {
    public static void main(String[] args) throws Exception {

        Juego juego = new Juego();
        juego.jugar();
    }
}