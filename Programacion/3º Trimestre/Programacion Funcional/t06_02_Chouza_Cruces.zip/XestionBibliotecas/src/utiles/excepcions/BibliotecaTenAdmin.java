package utiles.excepcions;

public class BibliotecaTenAdmin extends Exception{
    public BibliotecaTenAdmin(String mensaxe){
        super(mensaxe);
    }
}
