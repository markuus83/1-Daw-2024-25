package Enum;
public enum Conector {

    HDMI,
    VGA,
    DisplayPort,
    USB,
    PS2;
}
