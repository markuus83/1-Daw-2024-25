package utiles.excepcions;

public class ExemplarNonExiste  extends Exception{

    public ExemplarNonExiste(String mensaxe){
        super(mensaxe);
    }
    
    
}
