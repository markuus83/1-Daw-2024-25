package utiles.enumerandos;

public enum TipoUsuario {
    ADMINISTRADOR_XERAL,
    ADMINISTRADOR_BIBLIOTECA,
    CLIENTE;
}
