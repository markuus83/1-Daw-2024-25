package utiles.excepcions;

public class ISBNIncorrecto extends Exception{
    
    public ISBNIncorrecto(String mensaxe){
        super(mensaxe);
    }

}
