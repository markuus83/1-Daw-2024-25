package utiles.excepcions;

public class CorreoInvalido extends Exception{
    
    public CorreoInvalido(String mensaxe){
        super(mensaxe);
    }

}
