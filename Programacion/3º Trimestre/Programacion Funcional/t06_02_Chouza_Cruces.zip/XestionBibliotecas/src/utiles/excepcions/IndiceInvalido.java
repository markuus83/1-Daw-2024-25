package utiles.excepcions;

public class IndiceInvalido extends Exception{
    
    public IndiceInvalido(String mensaxe){
        super(mensaxe);
    }
}
