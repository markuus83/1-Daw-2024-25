package Modelo.Excepcions;

public class ISBNIncorrecto extends Exception{
    
    public ISBNIncorrecto(String mensaxe){
        super(mensaxe);
    }
}
