package Enum;
public enum Zocalo {
    
    LGA1700,
    AM5;
}
