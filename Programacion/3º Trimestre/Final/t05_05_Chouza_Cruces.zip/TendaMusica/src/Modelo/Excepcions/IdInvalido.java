package Modelo.Excepcions;

public class IdInvalido extends Exception{
    
    public IdInvalido(String mensaxe){
        super(mensaxe);
    }
}
