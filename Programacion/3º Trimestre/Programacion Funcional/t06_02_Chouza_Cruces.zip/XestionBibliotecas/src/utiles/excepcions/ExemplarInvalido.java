package utiles.excepcions;

public class ExemplarInvalido extends Exception{
    public ExemplarInvalido(String mensaxe){
        super(mensaxe);
    }
}
