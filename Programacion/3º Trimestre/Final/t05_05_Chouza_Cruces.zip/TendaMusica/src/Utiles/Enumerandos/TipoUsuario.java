package Utiles.Enumerandos;

public enum TipoUsuario {
    CLIENTE,
    ADMINISTRADOR;
}
