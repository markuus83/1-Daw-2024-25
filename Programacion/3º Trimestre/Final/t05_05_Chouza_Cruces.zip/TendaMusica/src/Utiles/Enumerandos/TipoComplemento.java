package Utiles.Enumerandos;

public enum TipoComplemento {
    LIBRO,
    ESTOXO;
}
