#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" 
Crea unha función recursiva <decimal_to_binario(numero: int) -> str> que obteña o número binario dun número N decimal.
"""

__author__ = "Marcos Chouza Cruces"