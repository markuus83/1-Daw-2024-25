package utiles.excepcions;

public class ContrasinalIncorrecto extends Exception{
    public ContrasinalIncorrecto(String mensaxe){
        super(mensaxe);
    }
}
