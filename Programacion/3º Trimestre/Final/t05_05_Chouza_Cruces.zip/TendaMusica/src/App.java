import Vista.MenuInicio;

public class App {
    public static void main(String[] args) throws Exception {
        new MenuInicio().run();
    }
}
