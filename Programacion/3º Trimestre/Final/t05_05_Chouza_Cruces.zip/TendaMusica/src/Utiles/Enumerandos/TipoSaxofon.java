package Utiles.Enumerandos;

public enum  TipoSaxofon {
    SOPRANO,
    ALTO,
    TENOR,
    BARITONO;
}
