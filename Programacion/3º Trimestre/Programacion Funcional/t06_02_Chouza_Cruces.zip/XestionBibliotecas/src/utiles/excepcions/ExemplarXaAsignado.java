package utiles.excepcions;

public class ExemplarXaAsignado extends Exception{
    public ExemplarXaAsignado(String mensaxe){
        super(mensaxe);
    }
}
