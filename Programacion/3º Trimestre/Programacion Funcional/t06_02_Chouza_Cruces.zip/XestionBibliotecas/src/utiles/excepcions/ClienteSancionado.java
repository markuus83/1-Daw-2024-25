package utiles.excepcions;

public class ClienteSancionado extends Exception {

    public ClienteSancionado(String mensaxe){
        super(mensaxe);
    }
    
}
