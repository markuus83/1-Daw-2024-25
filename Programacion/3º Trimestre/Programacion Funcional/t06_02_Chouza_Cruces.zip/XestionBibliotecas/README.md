# TODO

### NOTE - Clase Libro -> (EXEMPLAR)

    Atributo ArrayList<Exemplares>: Almacenar os diferentes exemplares de cada Libro


### NOTE - Clase EXEMPLAR -> (LIBRO)

    Atributo Libro libro: Almacenamos o libro ao cal pertence


### NOTE - Clase EXEMPLAR -> (BIBLIOTECA)

    Atributo ArrayList<Exemplares>: Almacenar os diferentes exemplares de cada Libro


### NOTE - Clase BIBLIOTECA -> (EXEMPLAR)

    Atributo Exemplar exemplar: Almacenamos o exemplar