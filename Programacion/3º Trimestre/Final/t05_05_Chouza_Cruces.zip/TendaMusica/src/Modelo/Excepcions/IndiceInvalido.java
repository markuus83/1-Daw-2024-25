package Modelo.Excepcions;

public class IndiceInvalido extends Exception{
    
    public IndiceInvalido(String mensaxe){
        super(mensaxe);
    }
}
