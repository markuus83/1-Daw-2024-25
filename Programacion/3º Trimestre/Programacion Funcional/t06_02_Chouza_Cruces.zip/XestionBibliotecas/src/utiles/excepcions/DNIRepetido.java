package utiles.excepcions;

public class DNIRepetido extends Exception{
    public DNIRepetido(String mensaxe){
        super(mensaxe);
    }
}
