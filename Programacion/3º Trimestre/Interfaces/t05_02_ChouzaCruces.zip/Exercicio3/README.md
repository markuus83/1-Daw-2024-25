## Getting Started

Modifica o exercicio 2, da tarefa T05_01 para que:

## Punto 1

A clase Deportista implanta a interface Comparable na que se utilizará como criterio de ordenación a data de nacemento.

## Punto 2

No programa principal, os deportistas débense de mostrar ordenados polo criterio de ordenación da clase Deportista.

## Punto 3

No programa principal, os tenistas débense de ordenar polo seu número de ranking

## Punto 4

No programa principal, tanto os pilotos como pilotos de F1 débense de ordenar por puntos de maior a menor. En cambio os pilotos de MotoGP a orde debe ser a inversa.