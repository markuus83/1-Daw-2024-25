package Modelo.Excepcions;

public class StockExcedente extends Exception{
    
    public StockExcedente(String mensaxe){
        super(mensaxe);
    }
}

