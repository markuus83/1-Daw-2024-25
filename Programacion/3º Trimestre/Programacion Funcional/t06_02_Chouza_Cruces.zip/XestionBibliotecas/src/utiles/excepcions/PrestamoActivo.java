package utiles.excepcions;

public class PrestamoActivo extends Exception {

    public PrestamoActivo(String mensaxe){
        super(mensaxe);
    }
    
}
