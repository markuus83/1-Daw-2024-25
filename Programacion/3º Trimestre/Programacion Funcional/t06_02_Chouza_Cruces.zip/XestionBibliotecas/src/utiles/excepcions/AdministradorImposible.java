package utiles.excepcions;

public class AdministradorImposible extends Exception{
    public AdministradorImposible(String mensaxe){
        super(mensaxe);
    }
}
