#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" 
Escribe unha función <celsius_to_farenheit(celsius: float/int) -> float> nun script que converta unha temperatura de graos Celsious a Farenheit. Se o parámetro que se lle pasa a función non é un número ou non é un número enteiro positivo, debe lanza unha excepción <ValueError>
"""

__author__ = "Marcos Chouza Cruces"