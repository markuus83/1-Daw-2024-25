package utiles.excepcions;

public class LibroExistente extends Exception{
    public LibroExistente(String mensaxe){
        super(mensaxe);
    }
}
