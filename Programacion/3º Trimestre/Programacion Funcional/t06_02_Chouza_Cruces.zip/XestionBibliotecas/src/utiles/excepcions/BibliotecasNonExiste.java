package utiles.excepcions;

public class BibliotecasNonExiste extends Exception{

    public BibliotecasNonExiste(String mensaxe){
        super(mensaxe);
    }
}
